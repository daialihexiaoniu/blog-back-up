---
name: 🐛 Bug 报告
about: 早起的虫子被你抓
---

<!--
请确保已阅读 [文档](https://docs.nexmoe.com) 内相关部分，并按照模版提供信息
否则 issue 将被立即关闭，请勿重复提issue
-->

### BUG 发生地址

### 预期是什么？

### 实际发生了什么？

### 额外信息（日志、报错等）

<!--
请确保您部署的是[主线 master 分支](https://github.com/nexmoe/hexo-theme-nexmoe/tree/master)的最新版
-->