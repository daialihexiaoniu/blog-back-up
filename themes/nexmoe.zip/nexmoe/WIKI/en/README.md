---
home: true
heroImage: https://i.loli.net/2019/08/08/5ceZJrGxLk8Shug.png
heroText: Nexmoe
tagline: 🔥 A more special blog theme
actionText: Get started →
actionLink: /en/hexo/
features:
- title: Shadow
  details: 
- title: Rounded Corners
  details: 
- title: Blurring
  details: 
footer: Made with ❤ by Nexmoe
---

    cd themes # Load theme directory
    git clone https://github.com/nexmoe/hexo-theme-nexmoe.git nexmoe # Installation
    cd nexmoe # Go to the Nexmoe theme directory
    npm i --save hexo-wordcount
    # Before Node version 7.6.0, please install the 2.x version (Node.js v7.6.0 and previous)
    # npm install hexo-wordcount@2 --save
    cp -i _config.example.yml _config.yml
