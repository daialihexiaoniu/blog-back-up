---
home: true
heroImage: https://i.loli.net/2019/08/25/fC5X3yNJBr1cDbP.png
heroText: Nexmoe
tagline: 🔥 一个比较特别的博客主题
actionText: 快速上手 →
actionLink: /hexo/
footer: Made with ❤ by Nexmoe
---

<style>
.home .hero img {
    max-height: unset;
}
</style>

``` bash
cd themes # 载入主题目录
git clone https://github.com/nexmoe/hexo-theme-nexmoe.git nexmoe # 安装
cd nexmoe # 进入 Nexmoe 主题目录
npm i --save hexo-wordcount
# Node 版本 7.6.0 之前,请安装 2.x 版本 (Node.js v7.6.0 and previous) 
# npm install hexo-wordcount@2 --save
cp -i _config.example.yml _config.yml
```